#! /usr/bin/env python

# This script converts mappings from one controller to another for Joystick Mapper presets
# Tested with Python 2.7.5 in Mac OS X
# Made by Rodrigo Rocha twitter: @RodrigoRodrigoR
# License: Public domain

keys = ["a", "b", "x", "y",
		"lb", "rb", "lt", "rt",
		"lclick", "rclick",
		"back", "start", "home",
		"dpad ^", "dpad v", "dpad <", "dpad >",
		"la ^", "la v", "la <", "la >",
		"ra ^", "ra v", "ra <", "ra >"]

x360 = ["btn 0", "btn 1", "btn 2", "btn 3",
		"btn 4", "btn 5", "axi 2 +", "axi 5 +",
		"btn 6", "btn 7",
		"btn 9", "btn 8", "btn 10",
		"btn 11", "btn 12", "btn 13", "btn 14",
		"axi 1 -", "axi 1 +", "axi 0 -", "axi 0 +",
		"axi 4 -", "axi 4 +", "axi 3 -", "axi 3 +"]

ps3  = ["btn 14", "btn 13", "btn 15", "btn 12",
		"btn 10", "btn 11", "btn 8", "btn 9",
		"btn 1", "btn 2",
		"btn 0", "btn 3", "btn 16",
		"btn 4", "btn 6", "btn 7", "btn 5",
		"axi 1 -", "axi 1 +", "axi 0 -", "axi 0 +",
		"axi 3 -", "axi 3 +", "axi 2 -", "axi 2 +"]

ps4	 = ["btn 1", "btn 2", "btn 0", "btn 3",
		"btn 4", "btn 5", "btn 6", "btn 7",
		"btn 10", "btn 11",
		"btn 8", "btn 9", "btn 12",
		"hat 0 U", "hat 0 D", "hat 0 L", "hat 0 R",
		"axi 1 -", "axi 1 +", "axi 0 -", "axi 0 +",
		"axi 5 -", "axi 5 +", "axi 2 -", "axi 2 +"]

# to add new mappgings, put the buttons/axes/hats in the same order as the others
# (see 'keys' for reference for xbox labels) and add the array to the 'validtypes' dictionary
validtypes = { "keys":keys, "x360": x360, "ps3": ps3, "ps4":ps4 }

# intro message
print '\n This script converts Joystick Mapper presets from one type of joystick to another'
print ' this is not perfect, and any contributions are welcome!'
print ' feel free to edit and add new types.\n'
print ' note that this script assumes current format for the presets (Joystick Mapper version 1.1.3 or earlier)'
print ' and this may change in the future.'
print ' note also that this script will not work properly whit presets that contain different types of joystick mappings\n'


import sys

def errormsg(msg):
	print '	Error:\n\t\t'+msg

def printvalid():
	print '	Valid types:\n\t\t' + ', '.join(validtypes.keys())

# only continue the script if the parameters are correct
if len(sys.argv) < 5:
	errormsg('Wrong parameters.')
	print '	Usage:\n\t\t'+sys.argv[0]+' [type-from] [readfilename] [type-destination] [writefilename]'
	printvalid()
	print '	Example:\n\t\t'+sys.argv[0]+' x360 preset1.txt ps3 preset2.txt\n'
	print '		 in this example, assuming "preset1.txt" file as a xbox 360 preset,'
	print '		 it will convert that to a ps3 preset and save it to "preset2.txt"\n'
	sys.exit()

# it is probably ok, continue the script
import io, json, os.path
#from pprint import pprint

# show what it will convert (see the internal txt file format to understand)
def showMap(a,b):
	if len(a) == len (b):
		for i, j in zip(a, b):
			print "{0}	---> {1}".format(i,j)
	else:
		print 'incorrect length'

# convert mapping from type 'frommap' to type 'destmap'
def convert(frommap, destmap, fromfile, destfile):
	from collections import OrderedDict

	json_data=open(fromfile)
	data = json.load(json_data)
	json_data.close()

	#print 'original:'
	#pprint(data)

	# This code could be much simpler but
	# I need to rebuild the json file in a predefined order because of the
	# way I handled the files inside the Joystick Mapper app
	# I should fix that in the future so it wont be needed
	newdata = OrderedDict()
	newdata["name"] = data["name"]
	newdata["tag"] = data["tag"]
	newjoysticks = []

	for joystick in data["joysticks"]:
		newjoystick = OrderedDict()
		newjoystick["tag"] = joystick["tag"]
		newbinds = OrderedDict()
		for bind in joystick["binds"]:
			newbind = destmap[frommap.index(bind)];
			newbinds[newbind] = joystick["binds"][bind]
		newjoystick["binds"] = OrderedDict(sorted(newbinds.items(), key=lambda t: t[0]))
		newjoysticks.append(newjoystick)

	newdata["joysticks"] = newjoysticks;

	# write the preset to the file
	with io.open(destfile, 'w', encoding='utf-8') as f:
		f.write(unicode(json.dumps(newdata, ensure_ascii=False, sort_keys=False, indent=2, separators=(',', ':'))))

	#print 'converted:'
	#pprint(newdata)


# testing and passing the parameters

frommap = validtypes.get(sys.argv[1])
destmap = validtypes.get(sys.argv[3])

if frommap == None:
	errormsg('Invalid origin type "' + sys.argv[1] + '"')
	printvalid()
	sys.exit()

if destmap == None:
	errormsg('Invalid destination type "' + sys.argv[3] + '"')
	printvalid()
	sys.exit()


fromfile = sys.argv[2]
destfile = sys.argv[4]

if not (os.path.exists(fromfile) and os.path.isfile(fromfile)):
	errormsg('Invalid origin file "'+fromfile+'"')
	sys.exit()

if (os.path.exists(destfile) and os.path.isfile(destfile)):
	errormsg('Destination file "'+destfile+'" exists, Proceed anyway?')
	proceed = raw_input("> ")
	print "You entered ", proceed
	if proceed.lower() in ['ok', '1', 'y', 'yes', 'yeah', 'yup', 'certainly', 'of course']:
		print "it will continue"
	else:
		print "it will NOT continue"
		sys.exit()

# Everythin is okay, just do it!
print '\nThese changes will be performed:'
showMap(frommap, destmap)
#showMap(keys, x360);
#showMap(x360, ps4);

convert(frommap, destmap, fromfile, destfile)
print '\nDone!\n'
