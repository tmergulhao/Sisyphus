var bindItemHtml = '<item style="display:none"><opt style="width: 40%; min-width: 240px;"><icon class="joystick"></icon>' +
		'<button class="scan" tooltip="Scan for joystick input">scan</button>' +
		'<select class="itype"><option value="btn">Button</option><option value="axi">Axis</option><option value="hat">Hat</option></select>' +
		'<select class="ibuttonvalue"></select>' +
		'<select class="iindex" style="display:none"></select>' +
		'<select class="iaxisvalue" style="display:none"><option value="+">+</option><option value="-">-</option></select>' +
		'<select class="ihatvalue" style="display:none"><option value="U">Up</option><option value="R">Right</option><option value="D">Down</option><option value="L">Left</option></select>' +
//		'<span>Threshold:&nbsp;</span><input type="range" name="points" min="1" max="100" class="ithreshold" />' +
		'</opt>' +
		
		'<opt style="min-width: 240px; margin-left:20px"><icon class="keyboard"></icon>' +
		'<select class="otype"><option value="key">Keyboard key</option><option value="mbt">Mouse Button</option><option value="mou">Mouse Motion</option><option value="whe">Mouse Wheel</option><option value="whs">Mouse Wheel step</option></select>' +
		'<select class="okey"></select>' +
		'<select class="omousebutton" style="display:none"><option value="0">0 (main click)</option><option value="1">1 (secondary click)</option><option value="2">2 (middle click)</option><option value="3">3</option><option value="4">4</option><option value="5">5</option><option value="6">6</option><option value="7">7</option></select>' +
		'<select class="oaxisdir" style="display:none"><option value="1 -">Up</option><option value="0 +">Right</option><option value="1 +">Down</option><option value="0 -">Left</option></select>' +
		'<input type="range" name="points" min="1" max="50" class="ospeed" tooltip="Max speed: 6x" value="6" style="display:none" />' +
		'</opt>' +
		
		'<opt style="position: absolute; left: 40%; margin-left:-18px"><icon class="arrowright"></icon></opt>' +
		'<opt class="right"><icon class="remove"> </icon></opt></item>';

var joystickItemHtml = '<itemgroup style="display:none"><header><icon class="fold"></icon>' + 
		'<text class="first"><span>Joystick #<joynum></joynum> : <br />&nbsp;</span></text>' +
		'<text class="second"><input type="text" class="tag" value="" /><br />' +
		'<joyname></joyname></text>' +
		'<icon class="sort" tooltip="Alphabetically Sort"></icon>' +
		'<icon class="duplicate" tooltip="Clone"></icon>' +
		'<icon class="remove" tooltip="Remove All"></icon></header><contents></contents>' +
		'<new><opt class="left"><icon class="add"> </icon></opt><text><p>Add a new bind.</p></text></new></itemgroup>';

var joystickNoneText = "no joysticks connected.";
var joystickNames = [];

// preenche ate o q nao existe
function fillSelectBoxes()
{
	var container;
	var filledFilterFunc = function() {
		if(!$(this).hasClass("filled")) {
			$(this).addClass("filled");
			return true;
		}
	};
	
	// Buttons
	container = $(".ibuttonvalue").filter(filledFilterFunc);
	var i;
	for (i = 0; i < 64; i++)
	{
		container.append('<option value="' + i +'">' + i +'</option>');
	}
	// Indexes
	container = $(".iindex").filter(filledFilterFunc);
	for (i = 0; i < 16; i++)
	{
		container.append('<option value="' + i +'">#' + i +'</option>');
	}
	// Key names
	$(".okey").filter(filledFilterFunc).html( $("#keynames").html() );
}

function updateHeightCallback() {
	appconfig.updateConfigWindowHeight();
}

function addJoystick(tag, shouldSlide) {
	if ( tag === undefined )
		tag = "Write here a tag to identify anything you want";

	var item = $("joysticks > groups")
		.append(joystickItemHtml)
		.find("> :last-child").find("input.tag").val(tag).end()
	
	if ( shouldSlide === undefined || shouldSlide === false )
		item.show();
	else
		item.slideDown(200, updateHeightCallback);
	
	item.end().find("> itemgroup").each(updateRelatedJoystick);
}

function clearJoysticks() {
	$("joysticks > groups").text("");
	$("#name").select();
}

function updateRelatedJoystick(i) {
	$(this).find("joynum").text(i);
	
	if (joystickNames.length >= (i+1)) {
		$(this).find("joyname").text(joystickNames[i]);
	} else {
		$(this).find("joyname").text(joystickNoneText);
	}
}

function selectInputInBind(joystickIndex, bindIndex, inputmap) {
	var item = $("joysticks > groups > itemgroup").eq(joystickIndex)
		.find("> contents > item").eq(bindIndex);
	
	selectInputInContext(item, inputmap);
}

function selectInputInContext(context, inputmap) {
	var imap = inputmap.split(" ");
	
	if (imap.length > 0) {
		switch(imap[0]) {
			case "btn":
				context.find(".ibuttonvalue").val(imap[1]).end();
				break;
			case "axi":
				context.find(".iindex").val(imap[1]).end();
				context.find(".iaxisvalue").val(imap[2]).end();
				break;
			case "hat":
				context.find(".iindex").val(imap[1]).end();
				context.find(".ihatvalue").val(imap[2]).end();
				break;
		}
		context.find(".itype").val(imap[0]).trigger("change").end();
	}
}

function selectOutputInContext(context, outputmap) {
	var omap = outputmap.split(" ");
	
	if (omap.length > 0) {
		switch(omap[0]) {
			case "key":
				context.find(".okey").val(omap[1]).end();
				break;
			case "mbt":
				context.find(".omousebutton").val(omap[1]).end();
				break;
			case "mou":
			case "whe":
			case "whs":
				context.find(".oaxisdir").val((omap[1])+ " " +(omap[2])).end();
				if ( !(omap[3] === undefined) )
					context.find(".ospeed").val(omap[3]).attr("tooltip", ("Max speed: " + omap[3] + "x"));
				break;
		}
		context.find(".otype").val(omap[0]).trigger("change").end();
	}
}


function addBind(joystickIndex, inputmap, outputmap) {
	var item = $("joysticks > groups > itemgroup").eq(joystickIndex)
		.find("contents").append(bindItemHtml).find(" > :last-child");
	fillSelectBoxes();
	
	selectInputInContext(item, inputmap);
	selectOutputInContext(item, outputmap);
	
	item.show();
}

function addNewBind(where, model) {
	$(where).find("contents").append(model);
	fillSelectBoxes();
	
	$("contents > :last-child").slideDown(200, updateHeightCallback);
}

function removeItem(item) {
	$(item).slideUp(400, function() {
		$(this).remove();
		appconfig.updateConfigWindowHeight();
		
		// seria melhor separar os removes
		if ($(this).is("itemgroup")) {
			// update joystick indexes
			$("joysticks > groups > itemgroup").each(updateRelatedJoystick);
		}
	});
}

// acho q tem algo errado aqui.......
jQuery.fn.swap = function(b){
    b = jQuery(b)[0];
    var a = this[0];
    var t = a.parentNode.insertBefore(document.createTextNode(''), a);
    b.parentNode.insertBefore(a, b);
    t.parentNode.insertBefore(b, t);
    t.parentNode.removeChild(t);
    return this;
};
// ..... ou aqui
function sortItem(item) {
	var ito = {"btn":0,"axi":1,"hat":2};
	var ind = [".ibuttonvalue",".iindex",".iindex"];
	
	var items = item.find("contents > item");
	/* sort types */
	for(i=items.length-1; i>=0; i--) {
		for(j=0; j<i; j++) {
			if (parseInt(ito[items.eq(i).find(".itype").val()]) < parseInt(ito[items.eq(j).find(".itype").val()])) {
				items.eq(i).swap(items.eq(j));
			}
		}
	}
	
	/* now sort indexes */
	for(i=items.length-1; i>=0; i--) {
		for(j=0; j<i; j++) {
			vall = parseInt(ito[items.eq(i).find(".itype").val()]);
			valr = parseInt(ito[items.eq(j).find(".itype").val()]);
			if (vall == valr && parseInt(items.eq(i).find(ind[vall]).val()) < parseInt(items.eq(j).find(ind[valr]).val()) ) {
				items.eq(i).swap(items.eq(j));
			}
		}
	}
}

function duplicateItem(item) {
	var orig = item.find("select");
	var clone = item.clone().hide();
	$(item).after(clone).next().slideDown(400, updateHeightCallback);
	item.parent().find("> itemgroup").each(updateRelatedJoystick);
	clone.find("select").each(function(i) {
		$(this).val(orig.eq(i).val());
	});
}

/* gera string a ser salva */
function generatePresetString() {
	return JSON.stringify( {
		"name" : $("#name").val(),
		"tag": $("#tag").val(),
		"joysticks" : 
			(function () {
				var arr = [];
				$("joysticks > groups > itemgroup").each(function(index) {
					arr[index] = {
						"tag" : $(this).find(".tag").val(),
						"binds" :
							(function(it) {
								var items = {};
								it.find("item").each(function(index) {
									var item = $(this);
					
									var name = item.find(".itype").val() + " ";
									if( name == "btn " ) {
										name += item.find(".ibuttonvalue").val();
									} else if( name == "hat " ) {
										name += item.find(".iindex").val() + " " +
											item.find(".ihatvalue").val();
									} else {
										name += item.find(".iindex").val() + " " +
											item.find(".iaxisvalue").val();
									}
													 
									var value = item.find(".otype").val() + " ";
									if( value == "key ") {
										value += item.find(".okey").val();
									} else if( value == "mbt " ) {
										value += item.find(".omousebutton").val();
									} else if( value == "whs " ) {
										value += item.find(".oaxisdir").val();
									} else {
										value += item.find(".oaxisdir").val() + " " + item.find(".ospeed").val();
									}
													 
									if (items[name] === undefined) {
										items[name] = [value];
									} else {
										items[name].push(value);
									}
								});

								return items;
							})($(this))
						};
				});

				return arr;   
			})()
		}, null, "\t");
}


/* */

function init()
{	
	$("body").on( {
		click: function() {
			var focused = $(this);
			if (!focused.hasClass("focused")) {
				focused.select().addClass("focused");;
			}
		},
		blur: function() {
			$(this).removeClass("focused");
		},
		keydown: function(e) {
			if (e.which == 13) $(this).blur();
		}
	}, "input[type='text']");
	
	$("body").on( {
		click: function() {
			$(this).focus();
		}
	}, "input");

	$("body > joysticks").on( {
		mouseenter: function(){
			$(this).parent().parent().addClass("alert");
		},
		mouseleave: function(){
			$(this).parent().parent().removeClass("alert");
		},
		click: function() {
			removeItem($(this).parent().parent());
		}
	}, "icon.remove");
	
	$("body > joysticks").on( {
		mouseenter: function(){
			$(this).parent().parent().addClass("alert2");
		},
		mouseleave: function(){
			$(this).parent().parent().removeClass("alert2");
		},
		click: function() {
			duplicateItem($(this).parent().parent());
			$(this).parent().parent().removeClass("alert2");
		}
	}, "icon.duplicate");
	
	$("body > joysticks").on( {
		mouseenter: function(){
			$(this).parent().parent().addClass("alert3");
		},
		mouseleave: function(){
			$(this).parent().parent().removeClass("alert3");
		},
		click: function() {
			sortItem($(this).parent().parent());
		}
	}, "icon.sort");

	$("joysticks > groups").on({
		change: function() {
			var val = $(this).val();
			var item = $(this).parent();
		
			if( val == "btn" ) {
				item.find(".iaxisvalue, .ihatvalue").fadeOut();
				item.find(".iindex").hide();
				item.find(".ibuttonvalue").show();
			} else if( val == "hat" ) {
				item.find(".iindex").show();
				item.find(".ibuttonvalue, .iaxisvalue").hide();
				
				item.find(".ihatvalue").fadeIn();
			} else {
				item.find(".iindex").show();
				item.find(".ibuttonvalue, .ihatvalue").hide();
				
				item.find(".iaxisvalue").fadeIn();
			}
		}
	}, "contents item .itype");
	
	$("joysticks > groups").on({
		change: function() {
			var val = $(this).val();
			var item = $(this).parent();
			
			if(	val == "key" ) {
				item.find("icon").attr("class", "keyboard");
			} else {
				item.find("icon").attr("class", "mouse");
			}
			
			if ( val == "key" ) {
				item.find(".omousebutton,.oaxisdir,.ospeed").hide();
				item.find(".okey").fadeIn();
			} else if ( val == "mbt") {
				item.find(".okey,.oaxisdir,.ospeed").hide();
				item.find(".omousebutton").fadeIn();
			} else {
				item.find(".okey,.omousebutton").hide();
				item.find(".oaxisdir").fadeIn();
				if ( val != "whs" )
					item.find(".ospeed").fadeIn();
				else
					item.find(".ospeed").hide();
			}
		}
	}, "contents item .otype");
	
	$("joysticks > groups").on({
		click: function() {
			var item = $(this).parent().parent().addClass("editing");
			var jindex = item.parent().parent().index();
			var bindex = item.index();
							   
			startModal();
			appconfig.scanJoystickInput_inBindNo_(jindex,bindex);
		}
	}, "contents item button.scan");
	
	
	$("joysticks > groups").on({
		click: function() {
			if($(this).hasClass("fold")) {
				$(this).addClass("unfold").removeClass("fold")
					.parent().parent().find("contents").slideUp(400, updateHeightCallback)
					.parent().find("new").slideUp(200);
			}
			else {
				$(this).addClass("fold").removeClass("unfold")
					.parent().parent().find("contents").slideDown(400, updateHeightCallback)
					.parent().find("new").slideDown(200);
			}
		}
	}, "itemgroup > header > icon.fold, itemgroup > header > icon.unfold");
	
	$("joysticks > groups").on({
		click: function() {
			$(this)
				.parent().find("contents").slideDown(200)
				.parent().find("header > opt.left > icon").addClass("fold").removeClass("unfold");
					
			addNewBind($(this).parent(), bindItemHtml);
		}
	}, "itemgroup > new");
	
	$("joysticks > groups").on({
		change: function() {
			$(this).attr("tooltip", "Max speed: " + $(this).val() + "x");
		}
	}, ".ospeed");
	
	$("joysticks > groups").on({
		blur:function() {
			$(this).val($(this).val().split("'").join(" ").split('"').join(" ")); // removing buggy characters.
		}
	}, "input[type=text].tag");
	
	$("joysticks > new").click(function() {
		addJoystick(undefined,true);
	});
	
	$("#name").select();
}
	
$(document).ready(init);
