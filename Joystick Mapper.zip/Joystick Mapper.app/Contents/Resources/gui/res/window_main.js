var presetItemHtml =
	'<item><filename></filename>'+
		'<opt class="left"><icon class="activated" tooltip="Use this preset"></icon></opt>'+
		'<text><h2></h2><p></p></text>'+
		'<opt class="right"><icon class="duplicate" tooltip="Clone this preset"></icon><icon class="edit" tooltip="Edit this preset"></icon><icon class="remove"></icon></opt></item>';
		
var lock = false;

function cleanPresetList()
{
	$("#presetList > contents").html("");
}

function addPresetUI(name, tag, filename)
{
	var node = $("#presetList > contents").append(presetItemHtml).find("> :last-child").hide();
	node.find("> text > h2").append(name);
	node.find("> text > p").append(tag);
	node.find("> filename").append(filename);
	return node.fadeIn(); //pq nao slidedown?
//	return node;
}

function createPreset()
{
	notifyStopPreset();
	
	var filename = generateFileName();
	var node = addPresetUI("New Preset", "No tag", filename).slideDown(200, function() {
		notifyPresetConfig(filename);	
	}).addClass("editing");
	startModal();
}

function editPreset(which)
{
	notifyStopPreset();
	
	which.addClass("editing");
	startModal();
	notifyPresetConfig(which.find("> filename").text());
}

function clonePreset(which)
{
	notifyStopPreset();
		
	var filename = generateFileNameWithName(which.find("> filename").text());	
	var clone = which.clone().hide();
	which.after(clone).next().slideDown(200, function() {
		notifyPresetConfig(filename);	
	}).addClass("editing").find("> filename").text(filename);
	
	startModal();
}

function removePreset(which)
{
	which.slideUp(300, function() {
		if ($(this).hasClass("selected")) {
			notifyStopPreset();
	    }
		notifyPresetDelete($(this).find("> filename").text());
		$(this).remove();
	});
}

function togglePreset(which)
{
	which.addClass("loading");
	if(which.hasClass("selected")) {
		var wait = notifyStopPreset();
	} else {
		if(notifyStopPreset() && notifyStartPreset(which.find("> filename").text())) {
			which.addClass("selected");
		} else {
			alert("Error:\nNo Joysticks connected.\n\nPlease connect, at least, one joystick before continue.");
			$('#blockLayer').hide();
		}
	}
	which.removeClass("loading");
}

function notifyStartPreset(filename)
{
	return app.activatePreset_(filename);
}
function notifyStopPreset()
{
	$(".selected").removeClass("selected");
	
	return app.deactivatePreset();
}
function notifyPresetConfig(filename)
{
	app.createOrEditPreset_(filename);
}
function notifyPresetDelete(filename)
{
	app.deletePreset_(filename);
}

function generateFileName()
{
	return app.generateValidFilename();
}
function generateFileNameWithName(name)
{
	return app.generateValidFilenameWithName_(name);
}

function init()
{
	$("#presetList > new").click(function() {
		if(!lock) {
			lock = true;
			createPreset();
			lock = false;
		}
	});
	
	$("body").on( {
		mouseenter: function(){
			$(this).parent().parent().addClass("alert");
		},
		mouseleave: function(){
			$(this).parent().parent().removeClass("alert");
		}
	}, "icon.remove").on( {
		mouseenter: function(){
			$(this).parent().parent().addClass("alert2");
		},
		mouseleave: function(){
			$(this).parent().parent().removeClass("alert2");
		}
	}, "icon.duplicate");
	
	$("#presetList").on( {
		click: function() {
			if (confirm("Are you sure you want to remove this Preset?"))
				removePreset($(this).parent().parent());
		}
	}, "icon.remove").on( {
		click: function() {
			if(!lock) {
				lock = true;
			    editPreset($(this).parent().parent());
			    lock = false;
			}
		}
	}, "icon.edit").on( {
		click: function() {
			if(!lock) {
				lock = true;
			    clonePreset($(this).parent().parent());
			    lock = false;
			}
		}
	}, "icon.duplicate").on( {
		click: function() {
			if(!lock) {
				lock = true;
				togglePreset($(this).parent().parent());
				lock = false;
			}
		}
	}, "icon.activated");
}
$(document).ready(init);
