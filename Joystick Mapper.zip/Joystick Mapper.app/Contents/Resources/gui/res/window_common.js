function startModal() {
	$("#modalLayer").fadeIn(500);
}
function stopModal() {
	$("#timeOut").text("");
	$("#modalLayer").fadeOut(400, function() {
		$(".editing").removeClass("editing").addClass("highlight")
			.delay(3000).show(0, function() {
				$(this).removeClass("highlight");
			});
	});
}
function getContentHeight() {
	return document.body.offsetHeight;
}

function updateTooltipText(context) {
	$("#tooltip").text(context.attr("tooltip"));
}

$(document).ready(function() {
	$("body").append('<div id="tooltip"></div>');

	$("itemgroup, joysticks").on({
		mouseenter: function(){
			updateTooltipText($(this));
			$("#tooltip").fadeIn(700);
		},
		mouseleave: function(){
			$("#tooltip").stop(true,true).hide();
		},
		mousemove: function(e){
			updateTooltipText($(this));
			$("#tooltip").css({
				"left" : (((e.clientX-61) < 0) ? 61 : e.pageX) + "px",
				"top" : e.pageY + "px" });
		}
	}, "*[tooltip]");
});

